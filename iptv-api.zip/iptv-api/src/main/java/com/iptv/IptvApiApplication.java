package com.iptv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IptvApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IptvApiApplication.class, args);
	}

}
